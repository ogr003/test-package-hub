{{ adapter.dispatch('test_quantile_transformer_result_with_tolerance')() }}
