{% test mock_schema_test(model, column_name) %}

SELECT
    1 AS p

{% endtest %}
