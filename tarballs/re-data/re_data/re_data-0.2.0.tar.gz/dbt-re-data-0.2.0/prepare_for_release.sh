cd integration_tests
pytest
cd ..
python generate_docs.py
