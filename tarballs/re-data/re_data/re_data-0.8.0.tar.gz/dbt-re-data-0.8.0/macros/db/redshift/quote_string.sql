
{%- macro redshift__quote_new_line() %}'\134\134n'{% endmacro %}