cd integration_tests
python run_tests.py
cd ..
python generate_docs.py
