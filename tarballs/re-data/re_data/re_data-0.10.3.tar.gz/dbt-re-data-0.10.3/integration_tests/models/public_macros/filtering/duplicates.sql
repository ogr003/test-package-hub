 {{ re_data.filter_get_duplicates(
        ref('duplicated'), ['transaction_id'], ['creation_time']) }}
