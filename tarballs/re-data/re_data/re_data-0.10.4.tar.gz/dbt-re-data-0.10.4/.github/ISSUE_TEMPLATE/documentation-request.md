---
name: Documentation request
about: Describe this issue template's purpose here.
title: "[DOCUMENTATION]"
labels: documentation
assignees: ''

---

**Tell us about the documentation you'd like us to add or update**

**Is anything not clear or outdates in the current version of docs?**
