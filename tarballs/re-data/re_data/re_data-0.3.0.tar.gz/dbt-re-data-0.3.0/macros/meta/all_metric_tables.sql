{% macro get_all_metric_tables() %}

    {{ return ['re_data_base_metrics'] }}

{% endmacro %}