{% macro postgres_type_db() %}
    {{ ('postgres', 'greenplum') }}
{% endmacro %}