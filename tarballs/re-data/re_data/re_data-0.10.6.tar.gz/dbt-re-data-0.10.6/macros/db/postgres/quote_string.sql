

{%- macro postgres__quote_new_line() %}'\\n'{% endmacro %}