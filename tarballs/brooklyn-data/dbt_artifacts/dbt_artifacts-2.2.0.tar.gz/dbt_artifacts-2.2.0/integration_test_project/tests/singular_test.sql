select 1 as failures from (select 2) where 1 = 2
