
### dbt models for Outbrain

Requires dbt >= 0.12.2
