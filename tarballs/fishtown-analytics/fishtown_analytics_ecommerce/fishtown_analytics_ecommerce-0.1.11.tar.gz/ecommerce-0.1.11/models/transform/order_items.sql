select * from {{var('order_items_table')}}
