select * from {{var('addresses_table')}}
