select * from {{var('products_table')}}
