select

    id,
    name,
    external_id,
    organization_id,
    email,
    phone,
    last_login_at,
    restricted_agent,
    role,
    suspended,
    created_at,
    updated_at
    
from {{var('users_table')}}
