# Zendesk
dbt data models for Zendesk.
