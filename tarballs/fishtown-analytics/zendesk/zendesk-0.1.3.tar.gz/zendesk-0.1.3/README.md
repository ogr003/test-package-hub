# Zendesk
dbt data models for Zendesk.

Requires dbt >= 0.12.2
