
{% macro bigquery__snowplow_web_events_time() %}

{{ config(enabled=False) }}

{% endmacro %}
