
{% macro bigquery__snowplow_web_events_scroll_depth() %}

{{ config(enabled=False) }}

{% endmacro %}
