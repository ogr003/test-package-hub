
select * from {{ var('snowplow:context:useragent') }}
