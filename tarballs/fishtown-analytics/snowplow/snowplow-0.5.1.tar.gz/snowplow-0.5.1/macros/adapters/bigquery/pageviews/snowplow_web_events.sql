
{% macro bigquery__snowplow_web_events() %}

{{ config(enabled=False) }}

{% endmacro %}
