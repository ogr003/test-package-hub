select *
from {{ref('stripe_mrr_churned')}}
