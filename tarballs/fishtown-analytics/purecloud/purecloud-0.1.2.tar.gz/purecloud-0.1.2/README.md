# purecloud
dbt data models for Purecloud.

Requires dbt >= 0.12.2
