select distinct *
from {{var('referrers_table')}}
