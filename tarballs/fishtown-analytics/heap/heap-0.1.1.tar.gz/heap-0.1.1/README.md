# heap
Open source analytics for Heap SQL

## Installation

(make sure to run dbt seed as this package depends on data in `referrer_mapping.csv`.)
