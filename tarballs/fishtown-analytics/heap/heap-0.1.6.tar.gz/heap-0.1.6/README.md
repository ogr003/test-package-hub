# heap
Open source analytics for Heap SQL

Requires dbt >= 0.12.2

## Installation

(make sure to run dbt seed as this package depends on data in `referrer_mapping.csv`.)
