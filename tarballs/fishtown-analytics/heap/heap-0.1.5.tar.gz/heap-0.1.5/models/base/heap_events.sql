select *
from {{var('events_table')}}
