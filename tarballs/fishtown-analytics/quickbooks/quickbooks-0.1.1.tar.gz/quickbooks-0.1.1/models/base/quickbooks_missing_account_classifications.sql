select 64 as account_id, 'Revenue' as classification union all
select 67, 'Liability' union all
select 73, 'Equity' union all
select 74, 'Equity' union all
select 97, 'Expense' union all
select 122, 'Expense' union all
select 132, 'Expense'
