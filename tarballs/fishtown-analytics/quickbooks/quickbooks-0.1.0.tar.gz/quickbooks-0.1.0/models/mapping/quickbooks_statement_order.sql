select 'Income' as account_attribute, 'is1' as statement, 1 as order union all
select 'Other Income', 'is1', 2 union all
select 'Cost of Goods Sold', 'is1', 3 union all
select 'Expense', 'is1', 4 union all
select 'Other Expense', 'is1', 5
