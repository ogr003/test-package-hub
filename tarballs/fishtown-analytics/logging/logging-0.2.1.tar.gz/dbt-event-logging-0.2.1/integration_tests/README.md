### dbt integration test suite for event-logging

These simply test that the package doesn't throw an error. No quality assurance
is done on the results.
