# facebook-ads
dbt data models for facebook ads
