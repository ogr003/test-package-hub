select
  schemaname as schema_name
, viewname as view_name
, viewowner as view_owner
from pg_views