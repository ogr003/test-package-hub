select
  classid
, objid
, objsubid
, refclassid
, refobjid
, refobjsubid
, deptype
from pg_depend
