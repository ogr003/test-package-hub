
{{ redshift.fetch_table_data_sql() }}
