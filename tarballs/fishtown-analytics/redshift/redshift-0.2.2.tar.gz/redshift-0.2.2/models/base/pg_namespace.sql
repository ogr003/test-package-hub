select
  oid
, nspname
, nspowner
, nspacl
from pg_namespace
