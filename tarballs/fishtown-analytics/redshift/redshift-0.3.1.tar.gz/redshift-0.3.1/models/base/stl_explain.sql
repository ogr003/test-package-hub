select

  userid as user_id
, query as query_id
, nodeid
, parentid
, plannode
, info

from stl_explain
