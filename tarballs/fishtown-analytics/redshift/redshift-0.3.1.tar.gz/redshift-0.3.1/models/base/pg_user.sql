select

  usesysid as user_id
, usename as username

from pg_user
