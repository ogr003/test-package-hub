
{{ redshift.fetch_constraint_data_sql() }}
