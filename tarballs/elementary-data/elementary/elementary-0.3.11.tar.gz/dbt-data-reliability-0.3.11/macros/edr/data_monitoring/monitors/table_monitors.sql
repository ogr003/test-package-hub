{% macro row_count() -%}
    count(*)
{%- endmacro %}