select 'a's as string
