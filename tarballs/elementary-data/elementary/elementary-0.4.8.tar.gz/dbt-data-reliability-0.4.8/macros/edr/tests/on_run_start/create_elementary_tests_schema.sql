{% macro create_elementary_tests_schema() %}
    {% if execute and flags.WHICH == 'test' %}
        {% set database_name, schema_name = elementary.get_package_database_and_schema('elementary') %}
        {% set schema_name = schema_name ~ '__tests' %}
        {%- if not adapter.check_schema_exists(database_name, schema_name) %}
            {{ elementary.edr_log("Creating Elementary's tests schema.") }}
            {% set schema_relation = api.Relation.create(database=database_name, schema=schema_name).without_identifier() %}
            {%- do dbt.create_schema(schema_relation) %}
            {% do adapter.commit() %}
        {%- endif %}
    {% endif %}
    {{ return('') }}
{% endmacro %}