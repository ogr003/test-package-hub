# materialize-dbt-utils Changelog

## 0.1.0 - 2021-01-31

* Initial release.
