select 1 as my_column
