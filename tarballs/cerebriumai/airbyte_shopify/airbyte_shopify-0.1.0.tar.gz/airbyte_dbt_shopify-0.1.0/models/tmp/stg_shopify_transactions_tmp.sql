select *
from {{ var('transactions') }}