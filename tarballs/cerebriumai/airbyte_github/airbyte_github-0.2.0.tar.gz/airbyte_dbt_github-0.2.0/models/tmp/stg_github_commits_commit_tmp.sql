select
    *
from {{ var('commits_commit') }}