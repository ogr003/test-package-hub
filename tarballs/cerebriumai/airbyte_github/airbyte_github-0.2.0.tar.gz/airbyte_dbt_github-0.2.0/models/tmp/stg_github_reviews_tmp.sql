select
    *
from {{ var('reviews') }}