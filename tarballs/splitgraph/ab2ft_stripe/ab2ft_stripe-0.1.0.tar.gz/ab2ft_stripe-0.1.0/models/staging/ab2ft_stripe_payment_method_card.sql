SELECT * FROM (VALUES(NULL,NULL,NULL))
t("payment_method_id","brand","funding")