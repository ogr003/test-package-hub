# athena-utils
Utility functions for dbt projects running on Athena
