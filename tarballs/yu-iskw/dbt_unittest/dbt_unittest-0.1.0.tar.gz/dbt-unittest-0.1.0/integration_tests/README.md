# Integration tests for `dbt-unittest`

## How to run

### BigQuery
```bash
bash run_tests.sh --target bigquery
```
