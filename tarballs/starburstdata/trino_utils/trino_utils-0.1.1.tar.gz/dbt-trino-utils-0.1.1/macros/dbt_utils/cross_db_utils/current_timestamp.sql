{% macro trino__current_timestamp() %}
    current_timestamp
{% endmacro %}
