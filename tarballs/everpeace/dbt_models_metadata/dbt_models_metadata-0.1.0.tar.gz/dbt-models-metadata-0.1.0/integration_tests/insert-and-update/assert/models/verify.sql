SELECT * FROM {{ source('test_schema', 'dbt_models_metadata')}}
