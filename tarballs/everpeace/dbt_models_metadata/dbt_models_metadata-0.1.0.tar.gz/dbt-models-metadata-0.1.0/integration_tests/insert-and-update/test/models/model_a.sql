select 
    * 
from {{ ref('seed_a') }}
