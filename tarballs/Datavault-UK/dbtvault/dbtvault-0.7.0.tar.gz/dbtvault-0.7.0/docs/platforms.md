{% docs platform__snowflake %}

Snowflake implementation
{% enddocs %}