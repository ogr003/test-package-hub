## Coming soon

We will soon be making available a downloadable example project running dbtvault with the Snowflake TPCH dataset.
This will showcase dbtvault with pre-written models, giving you further understanding of how it all works.

[Sign up](https://www.data-vault.co.uk/dbtvault/) and get notified when this is available!