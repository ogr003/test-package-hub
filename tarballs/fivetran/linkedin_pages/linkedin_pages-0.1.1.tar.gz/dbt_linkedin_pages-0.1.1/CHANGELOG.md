# dbt_linkedin_pages v0.1.1
- Added an intermediate table that filters the most recent records for `ugc_post_history` to avoid duplicate rows.

# dbt_linkedin_pages v0.1.0

The original release! The main focus of the package is to transform the core social media object tables into analytics-ready models that can be easily unioned in to other social media platform packages to get a single view. This is especially easy using our [Social Media Reporting package](https://github.com/fivetran/dbt_social_media_reporting).
