select * 
from {{ var('ticket') }}
