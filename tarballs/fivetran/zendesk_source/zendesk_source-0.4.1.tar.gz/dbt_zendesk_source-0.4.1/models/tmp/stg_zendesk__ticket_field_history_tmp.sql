select * 
from {{ var('ticket_field_history') }}
