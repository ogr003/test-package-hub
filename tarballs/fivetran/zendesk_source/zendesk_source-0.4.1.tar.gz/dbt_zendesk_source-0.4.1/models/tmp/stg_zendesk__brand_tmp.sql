select * 
from {{ var('brand') }}
