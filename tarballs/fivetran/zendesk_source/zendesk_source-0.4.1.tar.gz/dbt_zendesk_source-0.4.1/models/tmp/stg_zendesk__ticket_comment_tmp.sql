select * 
from {{ var('ticket_comment') }}
