select * 
from {{ var('user') }}
