select * 
from {{ var('organization') }}
