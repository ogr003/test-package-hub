select * 
from {{ var('ticket_tag') }}
