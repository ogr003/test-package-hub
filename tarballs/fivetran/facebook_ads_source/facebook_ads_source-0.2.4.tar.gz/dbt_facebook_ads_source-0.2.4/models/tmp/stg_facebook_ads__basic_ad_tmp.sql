select * from {{ var('basic_ad') }}
