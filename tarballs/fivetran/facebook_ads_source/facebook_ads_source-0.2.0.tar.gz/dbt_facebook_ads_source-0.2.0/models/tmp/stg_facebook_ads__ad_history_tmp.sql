select * from {{ var('ad_history') }}
