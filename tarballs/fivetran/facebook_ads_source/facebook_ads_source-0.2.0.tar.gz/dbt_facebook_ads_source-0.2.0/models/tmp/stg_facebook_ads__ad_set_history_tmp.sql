select * from {{ var('ad_set_history') }}
