select * 
from {{ var('channel_basic') }}
