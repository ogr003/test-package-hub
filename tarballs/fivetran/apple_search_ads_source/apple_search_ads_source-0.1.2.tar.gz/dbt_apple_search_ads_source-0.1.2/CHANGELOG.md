# dbt_apple_search_ads_source v0.1.2

This [PR #21](https://github.com/fivetran/dbt_apple_search_ads_source/pull/21) updates macros for history tables to only include columns that are referenced downstream.
# dbt_apple_search_ads_source v0.1.0 - v0.1.1

## Initial Release
- This is the initial release of this package. For more information refer to the [README](/README.md).