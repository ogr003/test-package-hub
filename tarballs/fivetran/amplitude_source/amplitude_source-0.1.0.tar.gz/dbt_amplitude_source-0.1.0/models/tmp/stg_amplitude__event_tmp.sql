select * 
from {{ var('event') }}
