select * 
from {{ var('event_type') }}
