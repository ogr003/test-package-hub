{{ salesforce_formula_utils.sfdc_formula_view(
    source_table='user_role',
    full_statement_version=true) 
}}