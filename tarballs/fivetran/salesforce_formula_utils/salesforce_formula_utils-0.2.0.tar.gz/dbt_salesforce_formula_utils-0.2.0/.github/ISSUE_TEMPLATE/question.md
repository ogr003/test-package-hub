---
name: Question
about: Confused about how to use the package? Ask us a question
title: QUESTION - [your question title here]
labels: question
assignees: ''

---

**Are you a Fivetran customer?** 
<!--- Please tell us your name, title and company -->

**Your Question**
<!--- What is the question you would like to ask us about the package --> 

**Additional context**
<!--- Add any other context or screenshots about the feature request here. -->

**Please indicate the level of urgency and business impact of this request** 
<!--- Is this question blocking you from completing urgent work? Give us more context to help us prioritize this question. -->
