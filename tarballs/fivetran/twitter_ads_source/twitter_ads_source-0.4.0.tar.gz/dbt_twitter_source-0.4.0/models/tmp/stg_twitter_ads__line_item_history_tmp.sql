select *
from {{ var('line_item_history') }}