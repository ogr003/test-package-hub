select *
from {{ var('tweet_url') }}