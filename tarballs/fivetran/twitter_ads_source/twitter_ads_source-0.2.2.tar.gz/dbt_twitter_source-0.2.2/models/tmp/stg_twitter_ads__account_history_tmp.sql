select *
from {{ var('account_history') }}