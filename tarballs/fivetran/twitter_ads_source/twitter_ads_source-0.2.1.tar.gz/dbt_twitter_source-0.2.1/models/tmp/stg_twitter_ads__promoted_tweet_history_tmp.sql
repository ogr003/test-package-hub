select *
from {{ var('promoted_tweet_history') }}