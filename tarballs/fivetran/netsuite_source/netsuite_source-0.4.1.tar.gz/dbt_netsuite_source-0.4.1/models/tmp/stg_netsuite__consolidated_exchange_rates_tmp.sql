select * 
from {{ var('consolidated_exchange_rates') }}
