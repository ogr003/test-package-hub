select * 
from {{ var('locations') }}
