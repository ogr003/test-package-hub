select * 
from {{ var('transactions') }}
