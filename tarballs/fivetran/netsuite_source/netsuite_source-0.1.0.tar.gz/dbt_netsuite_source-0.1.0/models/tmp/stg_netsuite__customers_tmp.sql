select * 
from {{ var('customers') }}
