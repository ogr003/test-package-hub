select * 
from {{ var('departments') }}
