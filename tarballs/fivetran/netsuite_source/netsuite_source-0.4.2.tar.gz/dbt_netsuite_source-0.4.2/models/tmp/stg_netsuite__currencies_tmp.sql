select * 
from {{ var('currencies') }}
