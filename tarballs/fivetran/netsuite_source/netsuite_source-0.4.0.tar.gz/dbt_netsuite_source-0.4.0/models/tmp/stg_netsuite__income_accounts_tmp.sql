select * 
from {{ var('income_accounts') }}
