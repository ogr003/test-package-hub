select * 
from {{ var('expense_accounts') }}
