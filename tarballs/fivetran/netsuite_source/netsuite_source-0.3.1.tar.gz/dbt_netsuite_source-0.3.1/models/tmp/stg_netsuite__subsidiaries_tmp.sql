select * 
from {{ var('subsidiaries') }}
