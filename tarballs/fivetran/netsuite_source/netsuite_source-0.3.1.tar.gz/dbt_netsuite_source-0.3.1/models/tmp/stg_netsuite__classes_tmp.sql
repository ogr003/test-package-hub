select * 
from {{ var('classes') }}
