select * 
from {{ var('accounts') }}
