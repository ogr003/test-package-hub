select * 
from {{ var('vendor_types') }}
