select * 
from {{ var('items') }}
