select * 
from {{ var('accounting_books') }}
