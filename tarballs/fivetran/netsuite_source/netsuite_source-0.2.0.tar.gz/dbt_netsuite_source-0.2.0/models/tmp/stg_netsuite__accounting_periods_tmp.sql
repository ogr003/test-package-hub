select * 
from {{ var('accounting_periods') }}
