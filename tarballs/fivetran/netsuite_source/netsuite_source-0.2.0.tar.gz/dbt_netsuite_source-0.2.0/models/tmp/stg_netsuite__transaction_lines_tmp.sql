select * 
from {{ var('transaction_lines') }}
