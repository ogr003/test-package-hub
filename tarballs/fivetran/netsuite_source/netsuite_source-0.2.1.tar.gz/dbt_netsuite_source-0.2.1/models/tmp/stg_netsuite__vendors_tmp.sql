select * 
from {{ var('vendors') }}
