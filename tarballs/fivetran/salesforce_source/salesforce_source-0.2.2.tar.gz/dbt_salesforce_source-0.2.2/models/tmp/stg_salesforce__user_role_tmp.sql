select *
from {{ var('user_role') }}