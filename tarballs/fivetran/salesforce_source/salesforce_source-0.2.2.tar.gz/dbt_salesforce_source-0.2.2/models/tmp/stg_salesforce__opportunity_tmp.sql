select *
from {{ var('opportunity') }}