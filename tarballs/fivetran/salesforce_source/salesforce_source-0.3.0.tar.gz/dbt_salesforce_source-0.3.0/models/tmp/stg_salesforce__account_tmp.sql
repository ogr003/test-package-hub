select *
from {{ var('account') }}