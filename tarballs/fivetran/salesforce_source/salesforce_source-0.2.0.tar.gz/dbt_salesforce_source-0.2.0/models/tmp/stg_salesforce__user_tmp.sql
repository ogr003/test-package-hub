select *
from {{ var('user') }}