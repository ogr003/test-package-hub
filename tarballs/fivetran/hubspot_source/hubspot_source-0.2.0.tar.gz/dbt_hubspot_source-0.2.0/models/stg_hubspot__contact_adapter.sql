select *
from {{ var('contact') }}