# dbt_greenhouse_source v0.3.1

## Bug Fixes
- Addition of the `meta` config within the relevant `src_greenhouse.yml` tables that are able to be disabled by the user. These configs allow the source freshness tests to skip over the disabled models. ([#15](https://github.com/fivetran/dbt_greenhouse_source/pull/15))

# dbt_greenhouse_source v0.1.0 -> v0.3.0
Refer to the relevant release notes on the Github repository for specific details for the previous releases. Thank you!