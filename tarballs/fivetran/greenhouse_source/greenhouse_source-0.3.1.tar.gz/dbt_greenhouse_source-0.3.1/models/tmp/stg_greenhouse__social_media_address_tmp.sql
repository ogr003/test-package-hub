select * from {{ var('social_media_address') }}
