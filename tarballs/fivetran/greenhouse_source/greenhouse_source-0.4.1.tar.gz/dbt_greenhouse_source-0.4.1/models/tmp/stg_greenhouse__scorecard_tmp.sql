select * from {{ var('scorecard') }}
