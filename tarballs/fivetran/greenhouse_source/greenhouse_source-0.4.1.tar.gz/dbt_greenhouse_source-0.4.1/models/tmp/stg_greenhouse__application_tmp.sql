select * from {{ var('application') }}
