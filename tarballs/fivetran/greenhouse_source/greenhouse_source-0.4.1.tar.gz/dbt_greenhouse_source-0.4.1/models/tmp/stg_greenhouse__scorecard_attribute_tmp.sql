select * from {{ var('scorecard_attribute') }}
