select * from {{ var('job_application') }}
