select * from {{ var('user_email') }}
