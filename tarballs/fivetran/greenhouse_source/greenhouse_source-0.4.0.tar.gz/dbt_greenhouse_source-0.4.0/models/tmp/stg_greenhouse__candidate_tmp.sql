select * from {{ var('candidate') }}
