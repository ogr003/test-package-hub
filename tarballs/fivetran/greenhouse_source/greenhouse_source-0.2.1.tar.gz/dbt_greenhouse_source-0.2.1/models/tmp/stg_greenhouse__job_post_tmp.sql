select * from {{ var('job_post') }}
