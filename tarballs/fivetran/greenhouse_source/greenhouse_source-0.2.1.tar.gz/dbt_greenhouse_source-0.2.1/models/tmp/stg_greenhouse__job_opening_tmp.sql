select * from {{ var('job_opening') }}
