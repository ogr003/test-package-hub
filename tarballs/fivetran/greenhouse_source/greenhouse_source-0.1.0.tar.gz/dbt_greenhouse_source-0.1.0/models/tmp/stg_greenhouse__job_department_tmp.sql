select * from {{ var('job_department') }}
