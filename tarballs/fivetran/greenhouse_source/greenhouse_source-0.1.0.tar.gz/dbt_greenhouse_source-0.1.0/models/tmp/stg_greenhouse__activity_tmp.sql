select * from {{ var('activity') }}
