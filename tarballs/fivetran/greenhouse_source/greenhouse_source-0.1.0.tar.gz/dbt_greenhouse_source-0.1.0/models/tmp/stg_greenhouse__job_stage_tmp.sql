select * from {{ var('job_stage') }}
