select * from {{ var('scheduled_interview') }}
