select * from {{ var('phone_number') }}
