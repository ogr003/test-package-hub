select * from {{ var('candidate_tag') }}
