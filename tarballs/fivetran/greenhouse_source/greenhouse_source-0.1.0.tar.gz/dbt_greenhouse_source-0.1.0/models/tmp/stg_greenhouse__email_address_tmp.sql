select * from {{ var('email_address') }}
