select * from {{ var('department') }}
