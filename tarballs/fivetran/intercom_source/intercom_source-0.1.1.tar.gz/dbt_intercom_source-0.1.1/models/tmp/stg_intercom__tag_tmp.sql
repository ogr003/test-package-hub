select * 
from {{ var('tag') }}
