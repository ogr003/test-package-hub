select * 
from {{ var('conversation_contact_history') }}
