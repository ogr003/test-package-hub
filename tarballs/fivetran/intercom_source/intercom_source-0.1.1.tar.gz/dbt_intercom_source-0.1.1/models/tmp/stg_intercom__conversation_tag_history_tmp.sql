select * 
from {{ var('conversation_tag_history') }}
