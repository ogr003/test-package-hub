select * 
from {{ var('contact_company_history') }}
