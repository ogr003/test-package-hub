select * 
from {{ var('contact_tag_history') }}
