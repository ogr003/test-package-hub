select * 
from {{ var('conversation_history') }}
