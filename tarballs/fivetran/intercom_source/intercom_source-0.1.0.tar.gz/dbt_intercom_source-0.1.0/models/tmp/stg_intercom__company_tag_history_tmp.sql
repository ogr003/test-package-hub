select * 
from {{ var('company_tag_history') }}
