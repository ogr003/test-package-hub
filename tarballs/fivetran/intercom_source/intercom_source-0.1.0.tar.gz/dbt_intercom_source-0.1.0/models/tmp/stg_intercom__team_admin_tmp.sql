select * 
from {{ var('team_admin') }}
