{% docs _fivetran_synced %}

The time when a record was last updated by Fivetran.
 
{% enddocs %}