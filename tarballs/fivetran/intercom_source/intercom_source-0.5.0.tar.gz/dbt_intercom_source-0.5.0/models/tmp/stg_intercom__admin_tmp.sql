select * 
from {{ var('admin') }}
