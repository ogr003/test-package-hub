select * 
from {{ var('contact_history') }}