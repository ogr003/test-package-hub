select * 
from {{ var('conversation_part_history') }}
