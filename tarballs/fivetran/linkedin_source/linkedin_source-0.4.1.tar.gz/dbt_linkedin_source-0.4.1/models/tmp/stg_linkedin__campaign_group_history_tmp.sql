select *
from {{ var('campaign_group_history') }}
