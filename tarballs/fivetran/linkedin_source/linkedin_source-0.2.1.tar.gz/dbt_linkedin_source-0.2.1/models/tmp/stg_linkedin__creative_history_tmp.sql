select *
from {{ var('creative_history') }}
