select *
from {{ var('ad_analytics_by_creative') }}
