select * 
from {{ var('billing_info_history') }}