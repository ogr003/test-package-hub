select * 
from {{ var('invoice_coupon_redemption_history') }}
