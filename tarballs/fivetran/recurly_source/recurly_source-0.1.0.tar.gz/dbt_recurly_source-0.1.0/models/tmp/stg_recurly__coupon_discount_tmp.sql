select * 
from {{ var('coupon_discount') }}
