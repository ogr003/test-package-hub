select * 
from {{ var('transaction_subscription') }}
