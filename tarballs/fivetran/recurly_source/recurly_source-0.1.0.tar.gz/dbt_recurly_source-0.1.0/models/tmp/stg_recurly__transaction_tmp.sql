select * 
from {{ var('transaction') }}
