select * 
from {{ var('invoice_subscription_history') }}
