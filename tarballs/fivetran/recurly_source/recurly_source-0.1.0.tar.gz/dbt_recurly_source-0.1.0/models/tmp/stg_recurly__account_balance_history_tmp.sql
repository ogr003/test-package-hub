select * 
from {{ var('account_balance_history') }}
