select * 
from {{ var('invoice_history') }}
