select * 
from {{ var('subscription_history') }}
