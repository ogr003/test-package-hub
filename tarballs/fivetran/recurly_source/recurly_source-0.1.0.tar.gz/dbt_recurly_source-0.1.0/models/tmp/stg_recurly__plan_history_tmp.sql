select *
from {{ var('plan_history') }}