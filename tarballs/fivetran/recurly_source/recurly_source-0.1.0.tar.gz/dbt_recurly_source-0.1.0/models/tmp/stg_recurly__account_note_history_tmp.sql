select * 
from {{ var('account_note_history') }}
