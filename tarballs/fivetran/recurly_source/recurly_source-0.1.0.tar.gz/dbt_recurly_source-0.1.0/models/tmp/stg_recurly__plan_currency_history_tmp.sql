select *
from {{ var('plan_currency_history') }}