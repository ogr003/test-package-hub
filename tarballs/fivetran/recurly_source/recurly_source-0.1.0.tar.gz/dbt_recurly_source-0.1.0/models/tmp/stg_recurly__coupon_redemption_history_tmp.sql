select * 
from {{ var('coupon_redemption_history') }}
