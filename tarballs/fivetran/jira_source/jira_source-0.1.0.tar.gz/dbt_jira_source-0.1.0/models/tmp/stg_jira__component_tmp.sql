select * from {{ var('component') }}
