select * 
from {{ var('resolution') }}