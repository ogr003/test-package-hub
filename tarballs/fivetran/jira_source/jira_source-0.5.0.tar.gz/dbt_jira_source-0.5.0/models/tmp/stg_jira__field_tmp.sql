select * 
from {{ var('field') }}