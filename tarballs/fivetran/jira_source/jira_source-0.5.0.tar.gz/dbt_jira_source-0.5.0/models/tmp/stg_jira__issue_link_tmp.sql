select * 
from {{ var('issue_link') }}