select * 
from {{ var('user') }}