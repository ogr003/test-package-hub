select * 
from {{ var('status') }}