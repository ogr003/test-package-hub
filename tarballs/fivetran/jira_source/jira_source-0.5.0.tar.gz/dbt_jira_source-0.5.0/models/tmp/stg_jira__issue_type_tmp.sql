select * 
from {{ var('issue_type') }}