select * 
from {{ var('status_category') }}