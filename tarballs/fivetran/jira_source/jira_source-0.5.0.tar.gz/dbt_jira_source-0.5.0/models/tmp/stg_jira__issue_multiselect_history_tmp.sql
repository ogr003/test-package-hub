select * 
from {{ var('issue_multiselect_history') }}