select * 
from {{ var('field_option') }}