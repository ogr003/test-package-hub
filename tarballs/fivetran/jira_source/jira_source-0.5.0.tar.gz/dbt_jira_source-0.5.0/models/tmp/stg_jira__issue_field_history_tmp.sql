select * 
from {{ var('issue_field_history') }}