select * 
from {{ var('issue') }}