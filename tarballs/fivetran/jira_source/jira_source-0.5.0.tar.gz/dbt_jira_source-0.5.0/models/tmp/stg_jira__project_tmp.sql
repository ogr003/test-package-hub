select * 
from {{ var('project') }}