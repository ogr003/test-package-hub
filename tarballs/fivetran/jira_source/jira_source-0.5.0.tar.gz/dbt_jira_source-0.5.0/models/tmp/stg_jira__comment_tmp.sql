select * 
from {{ var('comment') }}