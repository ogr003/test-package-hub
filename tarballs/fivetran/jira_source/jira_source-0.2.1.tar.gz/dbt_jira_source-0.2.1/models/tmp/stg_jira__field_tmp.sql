select * from {{ var('field') }}
