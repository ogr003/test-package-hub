select * from {{ var('comment') }}
