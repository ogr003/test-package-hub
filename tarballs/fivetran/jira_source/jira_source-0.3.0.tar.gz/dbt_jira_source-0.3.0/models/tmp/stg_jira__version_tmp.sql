select * from {{ var('version') }}
