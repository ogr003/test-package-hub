{% docs _fivetran_synced %}
The timestamp of when a record was last synced by Fivetran.
{% enddocs %}

{% docs _fivetran_deleted %}
Boolean representing whether the record has been deleted in the source system.
{% enddocs %}