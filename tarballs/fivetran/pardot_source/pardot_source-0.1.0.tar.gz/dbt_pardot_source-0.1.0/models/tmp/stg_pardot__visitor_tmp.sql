select * from {{ var('visitor') }}
