select * from {{ var('opportunity_prospect') }}
