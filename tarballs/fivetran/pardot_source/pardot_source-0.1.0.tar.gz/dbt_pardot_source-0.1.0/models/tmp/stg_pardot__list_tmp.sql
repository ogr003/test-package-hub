select * from {{ var('list') }}
