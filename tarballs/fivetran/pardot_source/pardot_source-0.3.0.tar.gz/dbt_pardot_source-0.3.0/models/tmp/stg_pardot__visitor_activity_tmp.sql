select * from {{ var('visitor_activity') }}
