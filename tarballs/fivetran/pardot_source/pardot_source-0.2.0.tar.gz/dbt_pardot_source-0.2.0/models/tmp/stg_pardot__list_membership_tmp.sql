select * from {{ var('list_membership') }}
