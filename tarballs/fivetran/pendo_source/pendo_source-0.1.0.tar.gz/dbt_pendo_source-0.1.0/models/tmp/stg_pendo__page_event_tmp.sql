select * 
from {{ var('page_event') }}
