select * 
from {{ var('group') }}
