select * 
from {{ var('guide_step_history') }}
