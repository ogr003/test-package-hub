select * 
from {{ var('feature_event') }}
