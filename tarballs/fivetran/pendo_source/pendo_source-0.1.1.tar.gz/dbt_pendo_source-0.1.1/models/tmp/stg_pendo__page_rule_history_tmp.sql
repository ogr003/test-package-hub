select * 
from {{ var('page_rule_history') }}
