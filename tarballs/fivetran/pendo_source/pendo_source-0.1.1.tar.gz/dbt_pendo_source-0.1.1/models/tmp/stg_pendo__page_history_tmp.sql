select * 
from {{ var('page_history') }}
