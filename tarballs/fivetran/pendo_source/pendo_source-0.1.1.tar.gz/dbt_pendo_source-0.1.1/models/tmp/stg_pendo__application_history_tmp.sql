select * 
from {{ var('application_history') }}
