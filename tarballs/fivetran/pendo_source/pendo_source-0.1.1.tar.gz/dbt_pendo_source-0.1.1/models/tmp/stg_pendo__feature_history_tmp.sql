select * 
from {{ var('feature_history') }}
