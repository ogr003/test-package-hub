select * 
from {{ var('visitor_account_history') }}
