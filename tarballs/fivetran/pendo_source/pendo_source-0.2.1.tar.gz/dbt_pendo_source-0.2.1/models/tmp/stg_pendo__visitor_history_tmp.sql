select * 
from {{ var('visitor_history') }}
