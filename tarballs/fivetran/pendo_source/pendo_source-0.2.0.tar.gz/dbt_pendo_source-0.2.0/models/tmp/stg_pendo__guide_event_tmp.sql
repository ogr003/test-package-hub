select * 
from {{ var('guide_event') }}
