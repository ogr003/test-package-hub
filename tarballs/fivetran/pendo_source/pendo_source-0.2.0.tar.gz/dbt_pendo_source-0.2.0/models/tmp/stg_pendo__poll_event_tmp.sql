select * 
from {{ var('poll_event') }}
