select * 
from {{ var('poll') }}
