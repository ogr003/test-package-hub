{% docs count_sends %}
Count of total sends from related email sends.
{% enddocs %}

{% docs count_opens %}
Count of total opens from related email sends.
{% enddocs %}

{% docs count_bounces %}
Count of total bounces from related email sends.
{% enddocs %}

{% docs count_clicks %}
Count of total clicks from related email sends.
{% enddocs %}

{% docs count_deliveries %}
Count of total deliveries from related email sends.
{% enddocs %}

{% docs count_unsubscribes %}
Count of total unsubscribes from related email sends.
{% enddocs %}

{% docs count_unique_opens %}
Count of unique opens from related email sends.
{% enddocs %}

{% docs count_unique_clicks %}
Count of unique clicks from related email sends.
{% enddocs %}
