select * from {{ var('ad_hourly_report') }}
