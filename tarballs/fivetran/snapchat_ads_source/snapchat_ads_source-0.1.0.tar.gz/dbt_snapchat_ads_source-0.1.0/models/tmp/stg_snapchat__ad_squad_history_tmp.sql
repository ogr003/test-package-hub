select * from {{ var('ad_squad_history') }}
