select * from {{ var('campaign_history') }}
