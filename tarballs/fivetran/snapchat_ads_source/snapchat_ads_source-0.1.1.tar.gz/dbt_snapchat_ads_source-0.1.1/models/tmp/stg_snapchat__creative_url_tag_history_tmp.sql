select * from {{ var('creative_url_tag_history') }}
