select * from {{ var('ad_account_history') }}
