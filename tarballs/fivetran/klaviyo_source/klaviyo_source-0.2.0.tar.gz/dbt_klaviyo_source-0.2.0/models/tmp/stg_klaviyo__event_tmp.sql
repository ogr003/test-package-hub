select * from {{ var('event_table') }}
