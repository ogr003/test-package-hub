select * from {{ var('metric') }}
