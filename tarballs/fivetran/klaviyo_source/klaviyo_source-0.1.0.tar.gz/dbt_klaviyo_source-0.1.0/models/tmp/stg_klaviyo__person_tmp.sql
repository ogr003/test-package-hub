select * from {{ var('person') }}
