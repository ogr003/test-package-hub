select * from {{ var('campaign') }}
