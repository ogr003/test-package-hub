select *
from {{ var('user_unsubscribed_channel_history') }}
