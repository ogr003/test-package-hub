select *
from {{ var('list') }}
