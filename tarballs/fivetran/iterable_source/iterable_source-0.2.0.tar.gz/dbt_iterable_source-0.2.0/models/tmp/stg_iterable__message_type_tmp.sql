select *
from {{ var('message_type') }}
