select *
from {{ var('template_history') }}
