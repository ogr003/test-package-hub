select *
from {{ var('campaign_suppression_list_history') }}
