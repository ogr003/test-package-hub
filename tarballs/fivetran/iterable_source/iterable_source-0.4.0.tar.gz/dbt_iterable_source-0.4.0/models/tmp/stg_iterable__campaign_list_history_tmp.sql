select *
from {{ var('campaign_list_history') }}
