select *
from {{ var('channel') }}
