select * 
from {{ var('event_extension') }}
