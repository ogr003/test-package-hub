select * 
from {{ var('user_history') }}
