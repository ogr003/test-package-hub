select *
from {{ var('connector') }}