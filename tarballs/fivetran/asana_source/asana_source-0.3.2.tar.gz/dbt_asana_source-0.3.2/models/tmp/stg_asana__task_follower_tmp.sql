select * 
from {{ var('task_follower') }}
