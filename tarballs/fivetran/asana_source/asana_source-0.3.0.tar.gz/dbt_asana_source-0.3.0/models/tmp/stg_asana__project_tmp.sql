select * 
from {{ var('project') }}
