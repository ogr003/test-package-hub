select * 
from {{ var('section') }}
