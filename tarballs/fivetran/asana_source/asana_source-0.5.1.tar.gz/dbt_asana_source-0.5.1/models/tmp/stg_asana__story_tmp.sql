select * 
from {{ var('story') }}
