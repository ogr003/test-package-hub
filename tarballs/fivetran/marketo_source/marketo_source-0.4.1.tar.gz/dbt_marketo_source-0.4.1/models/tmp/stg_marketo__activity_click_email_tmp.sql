select *
from {{ var('activity_click_email') }}
