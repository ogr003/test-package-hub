select *
from {{ var('program') }}
