select *
from {{ var('campaign') }}
