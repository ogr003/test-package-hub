select *
from {{ var('activity_send_email') }}
