select *
from {{ var('lead') }}
