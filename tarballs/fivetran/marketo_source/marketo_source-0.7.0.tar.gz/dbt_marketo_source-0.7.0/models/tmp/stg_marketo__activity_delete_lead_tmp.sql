select *
from {{ var('activity_delete_lead') }}
