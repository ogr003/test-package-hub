select *
from {{ var('lead_describe') }}
