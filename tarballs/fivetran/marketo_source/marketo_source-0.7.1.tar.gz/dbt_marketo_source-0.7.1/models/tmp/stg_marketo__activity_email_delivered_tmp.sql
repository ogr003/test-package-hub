select *
from {{ var('activity_email_delivered') }}
