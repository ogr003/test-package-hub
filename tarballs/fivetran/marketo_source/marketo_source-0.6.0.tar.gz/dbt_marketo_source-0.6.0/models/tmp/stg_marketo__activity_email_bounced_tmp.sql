select *
from {{ var('activity_email_bounced') }}
