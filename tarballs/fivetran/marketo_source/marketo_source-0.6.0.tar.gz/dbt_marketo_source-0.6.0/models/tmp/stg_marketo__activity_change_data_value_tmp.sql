select *
from {{ var('activity_change_data_value') }}
