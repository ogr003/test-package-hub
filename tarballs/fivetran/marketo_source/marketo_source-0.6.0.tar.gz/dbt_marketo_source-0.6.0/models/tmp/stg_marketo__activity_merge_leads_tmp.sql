select *
from {{ var('activity_merge_leads') }}
