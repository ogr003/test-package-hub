select *
from {{ var('activity_open_email') }}
