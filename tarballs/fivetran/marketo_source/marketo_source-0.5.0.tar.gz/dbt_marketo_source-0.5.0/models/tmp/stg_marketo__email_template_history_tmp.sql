select *
from {{ var('email_template_history') }}
