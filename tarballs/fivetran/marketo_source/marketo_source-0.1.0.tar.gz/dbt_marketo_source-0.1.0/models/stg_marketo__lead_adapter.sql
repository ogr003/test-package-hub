select *
from {{ var('lead') }}