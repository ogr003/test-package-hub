select *
from {{ var('activity_unsubscribe_email') }}
