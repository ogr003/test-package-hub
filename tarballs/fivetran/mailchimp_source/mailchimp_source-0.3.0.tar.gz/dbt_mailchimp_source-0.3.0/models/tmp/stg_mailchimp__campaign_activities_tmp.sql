select * from {{ var('campaign_recipient_activity') }}
