# dbt_mailchimp_source v0.2.0

## 🚨 Breaking Change 🚨
- Updating src_mailchimp database variable to reflect README files. Update `database` to `mailchimp_database`.([#7](https://github.com/fivetran/dbt_mailchimp_source/pull/8)).

## Contributors
- @dfagnan ([#7](https://github.com/fivetran/dbt_mailchimp_source/pull/8)).

# dbt_mailchimp_source v0.1.0

## Initial Release
- This is the initial release of this package. For more information refer to the [README](/README.md).
