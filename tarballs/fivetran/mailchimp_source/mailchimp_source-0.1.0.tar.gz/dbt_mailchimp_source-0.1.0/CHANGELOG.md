# dbt_mailchimp_source v0.1.0

## Initial Release
- This is the initial release of this package. For more information refer to the [README](/README.md).
