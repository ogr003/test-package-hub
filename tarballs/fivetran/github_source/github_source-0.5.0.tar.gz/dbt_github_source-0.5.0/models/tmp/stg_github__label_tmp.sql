select *
from {{ var('label') }}