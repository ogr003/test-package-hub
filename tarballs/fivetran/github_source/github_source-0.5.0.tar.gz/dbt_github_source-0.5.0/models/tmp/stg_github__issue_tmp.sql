select *
from {{ var('issue') }}
