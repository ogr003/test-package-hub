select *
from {{ var('issue_assignee') }}
