select *
from {{ var('user') }}
