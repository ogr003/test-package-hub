select * 
from {{ var('team') }}
