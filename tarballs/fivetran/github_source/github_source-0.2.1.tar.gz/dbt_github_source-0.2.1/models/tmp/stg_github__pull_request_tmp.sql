select *
from {{ var('pull_request') }}
