select *
from {{ var('issue_merged') }}
