select *
from {{ var('issue_label') }}
