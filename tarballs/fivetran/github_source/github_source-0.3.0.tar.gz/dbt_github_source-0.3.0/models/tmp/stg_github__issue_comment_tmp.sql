select *
from {{ var('issue_comment') }}
