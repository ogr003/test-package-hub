select *
from {{ var('issue_closed_history') }}
