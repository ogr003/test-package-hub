select * 
from {{ var('stats_crashes_app_version') }}
