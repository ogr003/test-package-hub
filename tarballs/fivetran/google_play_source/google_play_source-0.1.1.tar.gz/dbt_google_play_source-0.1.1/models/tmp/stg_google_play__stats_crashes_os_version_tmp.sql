select * 
from {{ var('stats_crashes_os_version') }}
