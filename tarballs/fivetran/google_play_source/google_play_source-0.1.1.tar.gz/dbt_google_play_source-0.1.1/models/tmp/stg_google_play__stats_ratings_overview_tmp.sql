select * 
from {{ var('stats_ratings_overview') }}
