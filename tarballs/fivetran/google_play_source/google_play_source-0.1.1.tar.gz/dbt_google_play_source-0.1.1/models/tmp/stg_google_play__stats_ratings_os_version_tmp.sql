select * 
from {{ var('stats_ratings_os_version') }}
