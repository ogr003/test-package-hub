select * 
from {{ var('stats_ratings_app_version') }}
