select * 
from {{ var('stats_installs_app_version') }}
