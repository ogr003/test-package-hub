select * 
from {{ var('stats_store_performance_traffic_source') }}
