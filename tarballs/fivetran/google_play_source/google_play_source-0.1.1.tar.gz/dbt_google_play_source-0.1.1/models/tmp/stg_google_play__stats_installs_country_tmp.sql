select * 
from {{ var('stats_installs_country') }}
