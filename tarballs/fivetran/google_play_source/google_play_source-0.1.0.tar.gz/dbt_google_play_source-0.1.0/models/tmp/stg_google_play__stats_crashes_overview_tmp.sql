select * 
from {{ var('stats_crashes_overview') }}
