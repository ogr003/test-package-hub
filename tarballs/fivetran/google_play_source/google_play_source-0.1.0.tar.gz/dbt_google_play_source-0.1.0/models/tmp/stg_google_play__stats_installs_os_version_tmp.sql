select * 
from {{ var('stats_installs_os_version') }}
