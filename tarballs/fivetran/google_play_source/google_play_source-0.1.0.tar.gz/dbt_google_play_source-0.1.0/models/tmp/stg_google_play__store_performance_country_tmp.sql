select * 
from {{ var('stats_store_performance_country') }}
