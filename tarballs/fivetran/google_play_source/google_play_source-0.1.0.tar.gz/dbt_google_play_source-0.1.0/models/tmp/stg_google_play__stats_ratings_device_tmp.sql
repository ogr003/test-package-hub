select * 
from {{ var('stats_ratings_device') }}
