select * from {{ var('ar_invoice_item') }}
