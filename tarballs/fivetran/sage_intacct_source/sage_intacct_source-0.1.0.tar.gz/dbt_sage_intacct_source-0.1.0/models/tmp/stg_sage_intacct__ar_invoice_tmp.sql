select * from {{ var('ar_invoice') }}
