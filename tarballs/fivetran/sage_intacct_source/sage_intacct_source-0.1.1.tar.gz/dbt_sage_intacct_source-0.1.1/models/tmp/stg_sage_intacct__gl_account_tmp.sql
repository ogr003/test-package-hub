select * from {{ var('gl_account') }}
