select * from {{ var('gl_detail') }}
