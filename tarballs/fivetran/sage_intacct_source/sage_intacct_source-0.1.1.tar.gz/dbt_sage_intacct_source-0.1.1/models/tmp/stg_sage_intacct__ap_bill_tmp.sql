select * from {{ var('ap_bill') }}
