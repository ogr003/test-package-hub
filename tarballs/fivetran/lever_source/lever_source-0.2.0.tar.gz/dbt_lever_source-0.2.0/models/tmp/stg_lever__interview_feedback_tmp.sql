select * from {{ var('interview_feedback') }}
