select * from {{ var('opportunity_tag') }}
