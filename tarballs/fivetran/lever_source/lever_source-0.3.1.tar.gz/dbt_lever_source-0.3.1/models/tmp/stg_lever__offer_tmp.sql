select * from {{ var('offer') }}
