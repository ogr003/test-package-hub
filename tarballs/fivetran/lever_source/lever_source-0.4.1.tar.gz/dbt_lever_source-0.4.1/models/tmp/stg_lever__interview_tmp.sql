select * from {{ var('interview') }}
