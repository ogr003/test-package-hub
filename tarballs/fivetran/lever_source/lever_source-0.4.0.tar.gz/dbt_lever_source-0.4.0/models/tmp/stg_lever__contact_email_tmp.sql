select * from {{ var('contact_email') }}
