select * from {{ var('opportunity_source') }}
