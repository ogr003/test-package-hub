select * from {{ var('posting') }}
