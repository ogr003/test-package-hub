select * from {{ var('stage') }}
