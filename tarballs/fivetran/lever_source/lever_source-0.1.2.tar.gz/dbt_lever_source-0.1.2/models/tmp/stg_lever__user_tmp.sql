select * from {{ var('user') }}
