select * from {{ var('opportunity_stage_history') }}
