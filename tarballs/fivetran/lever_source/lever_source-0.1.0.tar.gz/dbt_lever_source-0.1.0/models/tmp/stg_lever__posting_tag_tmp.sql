select * from {{ var('posting_tag') }}
