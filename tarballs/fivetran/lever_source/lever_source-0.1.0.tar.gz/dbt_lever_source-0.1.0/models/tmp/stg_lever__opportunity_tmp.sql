select * from {{ var('opportunity') }}
