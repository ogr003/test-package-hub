select * from {{ var('contact_link') }}
