# dbt_fivetran_utils v0.2.8

## 🚨 Breaking Changes
- n/a

## Bug Fixes
- n/a

## Features
- Added this changelog to capture iterations of the package!
- Added the `add_dbt_source_relation()` macro, which passes the `dbt_source_relation` column created by `union_data()` to `source_relations()` in package staging models. See the README for more details on its appropriate usage.

## Under the Hood
- n/a