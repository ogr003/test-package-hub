select * 
from {{ var('usage_territory') }}
