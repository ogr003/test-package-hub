select * 
from {{ var('usage_device') }}
