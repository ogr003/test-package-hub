select * 
from {{ var('usage_app_version') }}
