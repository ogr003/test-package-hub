select * 
from {{ var('crashes_app_version') }}
