select * 
from {{ var('app_store_platform_version') }}
