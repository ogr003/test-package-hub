select * 
from {{ var('crashes_platform_version') }}
