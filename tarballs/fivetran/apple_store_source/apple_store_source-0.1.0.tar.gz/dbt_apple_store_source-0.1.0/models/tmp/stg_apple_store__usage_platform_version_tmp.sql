select * 
from {{ var('usage_platform_version') }}
