select * 
from {{ var('downloads_device') }}
