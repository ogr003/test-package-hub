select * 
from {{ var('app_store_territory') }}
