select * 
from {{ var('downloads_territory') }}
