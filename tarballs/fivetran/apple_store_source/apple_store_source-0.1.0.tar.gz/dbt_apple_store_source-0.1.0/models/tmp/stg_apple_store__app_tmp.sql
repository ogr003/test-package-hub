select * 
from {{ var('app') }}
