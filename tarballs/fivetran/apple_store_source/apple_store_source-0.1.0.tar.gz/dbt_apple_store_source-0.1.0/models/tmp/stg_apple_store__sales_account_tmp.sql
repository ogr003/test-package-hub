select * 
from {{ var('sales_account') }}
