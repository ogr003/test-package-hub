select * 
from {{ var('downloads_platform_version') }}
