select * 
from {{ var('product_source') }}