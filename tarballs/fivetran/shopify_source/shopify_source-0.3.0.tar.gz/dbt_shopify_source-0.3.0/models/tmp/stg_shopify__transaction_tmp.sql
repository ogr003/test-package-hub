select *
from {{ var('transaction_source') }}
