select * from {{ var('order_adjustment_source') }}
