select * 
from {{ var('product_variant_source') }}