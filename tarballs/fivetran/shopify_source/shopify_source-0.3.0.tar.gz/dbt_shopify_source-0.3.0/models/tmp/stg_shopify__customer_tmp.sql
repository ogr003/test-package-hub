select * 
from {{ var('customer_source') }}