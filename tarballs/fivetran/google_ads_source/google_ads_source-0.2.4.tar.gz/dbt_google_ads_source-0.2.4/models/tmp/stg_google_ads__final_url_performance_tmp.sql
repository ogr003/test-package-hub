select *
from {{ var('google_ads__final_url_performance') }}