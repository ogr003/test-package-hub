select *
from {{ var('google_ads__criteria_performance') }}