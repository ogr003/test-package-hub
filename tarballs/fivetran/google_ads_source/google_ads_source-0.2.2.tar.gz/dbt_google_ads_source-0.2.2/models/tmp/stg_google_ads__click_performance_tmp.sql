select *
from {{ var('google_ads__click_performance') }}