select * 
from {{ var('fee') }}
