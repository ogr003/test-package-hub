select * 
from {{ var('payment_intent') }}
