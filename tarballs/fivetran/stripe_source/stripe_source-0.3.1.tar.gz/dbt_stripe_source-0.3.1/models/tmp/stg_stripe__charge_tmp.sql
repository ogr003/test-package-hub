select * 
from {{ var('charge') }}
