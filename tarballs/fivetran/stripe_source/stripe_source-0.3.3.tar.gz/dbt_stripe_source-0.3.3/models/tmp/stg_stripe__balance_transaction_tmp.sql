select * 
from {{ var('balance_transaction') }}
