select * 
from {{ var('card') }}
