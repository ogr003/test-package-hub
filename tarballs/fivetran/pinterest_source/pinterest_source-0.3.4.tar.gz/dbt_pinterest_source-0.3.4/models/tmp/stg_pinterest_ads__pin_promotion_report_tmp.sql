select *
from {{ var('pin_promotion_report') }}
