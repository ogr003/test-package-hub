select *
from {{ var('pin_promotion_history') }}
