select *
from {{ var('ad_group_history') }}
