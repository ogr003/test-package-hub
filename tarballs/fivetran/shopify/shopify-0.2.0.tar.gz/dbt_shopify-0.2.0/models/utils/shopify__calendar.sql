{{ dbt_utils.date_spine(
    datepart="day",
    start_date="'2019-01-01'",
    end_date="current_date"
   )
}}