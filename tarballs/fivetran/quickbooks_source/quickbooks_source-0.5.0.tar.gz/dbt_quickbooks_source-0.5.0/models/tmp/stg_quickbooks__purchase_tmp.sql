select * 
from {{ var('purchase') }}
