select * 
from {{ var('customer') }}
