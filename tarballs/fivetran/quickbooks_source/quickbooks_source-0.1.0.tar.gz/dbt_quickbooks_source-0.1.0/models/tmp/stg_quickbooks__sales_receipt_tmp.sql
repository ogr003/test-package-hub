select * 
from {{ var('sales_receipt') }}
