select * 
from {{ var('vendor') }}
