select * 
from {{ var('purchase_line') }}
