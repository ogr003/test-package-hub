select * 
from {{ var('sales_receipt_line') }}
