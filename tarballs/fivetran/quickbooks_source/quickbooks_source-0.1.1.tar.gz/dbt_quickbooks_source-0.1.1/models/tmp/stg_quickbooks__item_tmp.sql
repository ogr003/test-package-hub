select * 
from {{ var('item') }}
