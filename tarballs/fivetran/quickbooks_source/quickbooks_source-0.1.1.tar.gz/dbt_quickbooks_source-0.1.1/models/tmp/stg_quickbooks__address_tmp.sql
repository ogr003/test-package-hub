select * 
from {{ var('address') }}
