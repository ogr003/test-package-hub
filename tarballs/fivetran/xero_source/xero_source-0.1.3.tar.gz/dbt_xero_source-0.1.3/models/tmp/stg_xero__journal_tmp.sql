select * from {{ var('journal') }}
