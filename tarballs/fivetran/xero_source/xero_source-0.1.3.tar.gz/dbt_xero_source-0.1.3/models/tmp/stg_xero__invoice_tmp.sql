select * from {{ var('invoice') }}
