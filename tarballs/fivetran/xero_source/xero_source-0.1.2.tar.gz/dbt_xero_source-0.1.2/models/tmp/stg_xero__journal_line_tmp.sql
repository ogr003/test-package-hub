select * from {{ var('journal_line') }}
