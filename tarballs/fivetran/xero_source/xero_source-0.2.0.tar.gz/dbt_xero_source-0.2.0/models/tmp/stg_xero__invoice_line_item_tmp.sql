select * from {{ var('invoice_line_item') }}
