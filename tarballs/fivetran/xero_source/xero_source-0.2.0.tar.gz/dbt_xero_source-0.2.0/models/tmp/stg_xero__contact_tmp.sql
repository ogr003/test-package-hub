select * from {{ var('contact') }}
