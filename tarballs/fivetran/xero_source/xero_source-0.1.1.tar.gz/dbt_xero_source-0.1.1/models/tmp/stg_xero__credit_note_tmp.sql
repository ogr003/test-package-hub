select * from {{ var('credit_note') }}
