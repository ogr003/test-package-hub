select *
from {{ var('ad_report_hourly') }}