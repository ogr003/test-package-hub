select *
from {{ var('campaign_report_hourly') }}