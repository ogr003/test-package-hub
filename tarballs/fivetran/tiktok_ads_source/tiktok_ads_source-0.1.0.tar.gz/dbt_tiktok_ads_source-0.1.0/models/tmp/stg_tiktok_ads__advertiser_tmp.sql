select *
from {{ var('advertiser') }}