{{ 
  config(tags=["requires_script"]) 
}}

select 1 as id
