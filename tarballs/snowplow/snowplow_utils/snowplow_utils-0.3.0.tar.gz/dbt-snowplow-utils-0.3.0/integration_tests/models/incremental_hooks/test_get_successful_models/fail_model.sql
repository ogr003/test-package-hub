{{ 
  config(tags=["requires_script"]) 
}}

elect 1 as id
