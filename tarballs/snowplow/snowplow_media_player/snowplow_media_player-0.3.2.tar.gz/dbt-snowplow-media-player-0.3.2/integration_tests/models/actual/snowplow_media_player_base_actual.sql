
select
    *
from {{ ref('snowplow_media_player_base') }}
