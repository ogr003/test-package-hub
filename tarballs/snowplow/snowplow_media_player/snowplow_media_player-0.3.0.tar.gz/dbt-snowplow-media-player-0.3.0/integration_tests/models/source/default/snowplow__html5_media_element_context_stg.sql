
select
  *

from {{ ref('snowplow_html5_media_element_context') }}
