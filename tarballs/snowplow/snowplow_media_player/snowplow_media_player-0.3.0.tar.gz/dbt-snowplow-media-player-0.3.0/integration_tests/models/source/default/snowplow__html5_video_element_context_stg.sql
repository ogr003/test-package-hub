
select
  *

from {{ ref('snowplow_html5_video_element_context') }}


