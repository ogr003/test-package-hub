
select
  *

from {{ ref('snowplow_youtube_context') }}

