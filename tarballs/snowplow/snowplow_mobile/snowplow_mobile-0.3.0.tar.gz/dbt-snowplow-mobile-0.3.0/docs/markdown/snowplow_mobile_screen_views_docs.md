{% docs table_screen_views_this_run %}

This staging table contains all the screen views for the given run of the mobile model. It possess all the same columns as `snowplow_mobile_screen_views`. If building a custom module that requires screen view events, this is the table you should reference.

{% enddocs %}
