
select *

from {{ ref('snowplow_mobile_sessions_expected') }}
