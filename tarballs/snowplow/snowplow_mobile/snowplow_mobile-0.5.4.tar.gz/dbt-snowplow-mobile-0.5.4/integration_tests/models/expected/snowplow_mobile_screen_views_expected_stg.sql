
select *

from {{ ref('snowplow_mobile_screen_views_expected') }}
