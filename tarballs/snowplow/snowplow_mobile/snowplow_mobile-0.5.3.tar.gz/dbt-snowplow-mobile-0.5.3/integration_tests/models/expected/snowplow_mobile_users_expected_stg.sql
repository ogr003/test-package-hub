
select *

from {{ ref('snowplow_mobile_users_expected') }}
