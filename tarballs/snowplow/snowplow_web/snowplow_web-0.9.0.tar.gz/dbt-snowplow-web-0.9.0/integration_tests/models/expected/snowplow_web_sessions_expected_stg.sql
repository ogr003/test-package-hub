
select * 

from {{ ref('snowplow_web_sessions_expected') }}
