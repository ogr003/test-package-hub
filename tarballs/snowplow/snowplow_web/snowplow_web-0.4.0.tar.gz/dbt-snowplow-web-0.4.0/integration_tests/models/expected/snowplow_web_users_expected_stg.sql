
select * 

from {{ ref('snowplow_web_users_expected') }}
