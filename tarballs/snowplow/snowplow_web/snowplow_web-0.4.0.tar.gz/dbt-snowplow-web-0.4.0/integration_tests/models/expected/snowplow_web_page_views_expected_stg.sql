
select * 

from {{ ref('snowplow_web_page_views_expected') }}
