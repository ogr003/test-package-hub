
{{
    dbt_project_evaluator.get_nodes()
}}