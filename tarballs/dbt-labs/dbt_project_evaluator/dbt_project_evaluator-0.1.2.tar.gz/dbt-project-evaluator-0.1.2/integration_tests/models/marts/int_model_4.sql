-- depends on: {{ ref('stg_model_1') }}
-- depends on: {{ source('source_1', 'table_2') }}

select 1 as id
