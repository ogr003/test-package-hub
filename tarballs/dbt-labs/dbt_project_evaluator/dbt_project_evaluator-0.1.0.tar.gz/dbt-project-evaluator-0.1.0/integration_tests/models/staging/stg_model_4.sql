-- depends on: {{ ref('stg_model_2') }}

select 1 as id
