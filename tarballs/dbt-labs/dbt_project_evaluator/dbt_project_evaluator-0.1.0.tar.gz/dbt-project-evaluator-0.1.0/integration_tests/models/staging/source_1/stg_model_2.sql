-- depends on: {{ source('source_1', 'table_1') }}
-- depends on: {{ source('source_1', 'table_2') }}

select 1 as id
