{{ source('source_2', 'table_3') }}
