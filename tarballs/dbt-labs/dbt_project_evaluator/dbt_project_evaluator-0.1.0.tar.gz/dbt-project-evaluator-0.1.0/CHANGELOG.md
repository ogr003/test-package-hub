# dbt-project-evaluator v0.1.0

## New features
All of them!

## Contributors:
- [@graciegoheen](https://github.com/graciegoheen)
- [@b-per](https://github.com/b-per)
- [@wasilaq](https://github.com/wasilaq)
- [@patkearns](https://github.com/patkearns) 
- [@dave-connors-3](https://github.com/dave-connors-3)