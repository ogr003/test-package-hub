
{{ 
    get_exposures() 
}}
