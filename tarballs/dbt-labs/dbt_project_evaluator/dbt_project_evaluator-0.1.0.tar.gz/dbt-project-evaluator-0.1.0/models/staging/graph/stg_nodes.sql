
{{
    get_nodes()
}}