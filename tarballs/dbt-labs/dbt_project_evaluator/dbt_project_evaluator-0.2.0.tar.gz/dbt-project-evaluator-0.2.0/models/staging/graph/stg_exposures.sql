
{{ 
    dbt_project_evaluator.get_exposures() 
}}
