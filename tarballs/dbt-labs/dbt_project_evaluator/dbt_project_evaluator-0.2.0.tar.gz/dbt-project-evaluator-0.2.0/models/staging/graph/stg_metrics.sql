
{{ 
    dbt_project_evaluator.get_metrics()
}}
