
{{ stitch_utils.coalesce_fields(ref('data_coalesce_fields')) }}