
select * from {{ var('snowplow:context:performance_timing') }}
