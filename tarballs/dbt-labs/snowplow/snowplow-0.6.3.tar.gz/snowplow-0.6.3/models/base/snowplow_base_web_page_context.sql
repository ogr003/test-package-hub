
select * from {{ var('snowplow:context:web_page') }}
