
select * from {{ var('snowplow:events') }}
