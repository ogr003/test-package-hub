
{% macro bigquery__snowplow_web_events_internal_fixed() %}

{{ config(enabled=False) }}

{% endmacro %}
