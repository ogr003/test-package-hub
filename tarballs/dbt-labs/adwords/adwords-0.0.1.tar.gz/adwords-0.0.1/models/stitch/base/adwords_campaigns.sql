select *
from {{ var('campaigns_base_table') }}
