select 
    * 
from {{ ref('model_data_a') }}
