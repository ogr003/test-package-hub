select 1 as my_col
