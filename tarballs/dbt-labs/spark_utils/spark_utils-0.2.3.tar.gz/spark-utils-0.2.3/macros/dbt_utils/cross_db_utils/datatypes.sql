{# numeric  ------------------------------------------------     #}

{% macro spark__type_numeric() %}
    decimal(28, 6)
{% endmacro %}
