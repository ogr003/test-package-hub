# spark-utils v0.2.4
🚨 This is a compatibility release in preparation for `dbt-core` v1.0.0 (🎉)
