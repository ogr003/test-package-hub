### segment_web_page_views

{% docs segment_web_page_views %}

This is a base model for Segment's web page views table. It does some straightforward renaming and parsing of Segment raw data in this table.

{% enddocs %}
