## dbt-utils v0.5.1

## Fixes

## Features

## Quality of life
* Improve release process, and fix tests (#251)
* Make deprecation warnings more useful (#258 @tayloramurphy)
