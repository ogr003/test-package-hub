select
  oid
, nspname
, nspowner
, nspacl
from pg_catalog.pg_namespace
