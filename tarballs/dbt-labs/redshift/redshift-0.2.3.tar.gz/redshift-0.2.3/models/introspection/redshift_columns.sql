
{{ redshift.fetch_column_data_sql() }}
