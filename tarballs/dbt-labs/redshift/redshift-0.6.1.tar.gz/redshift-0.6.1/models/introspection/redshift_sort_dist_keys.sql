
{{ redshift.fetch_sort_dist_key_data_sql() }}
