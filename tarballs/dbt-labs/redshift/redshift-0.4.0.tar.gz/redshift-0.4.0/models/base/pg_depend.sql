select
  classid
, objid
, objsubid
, refclassid
, refobjid
, refobjsubid
, deptype
from pg_catalog.pg_depend
