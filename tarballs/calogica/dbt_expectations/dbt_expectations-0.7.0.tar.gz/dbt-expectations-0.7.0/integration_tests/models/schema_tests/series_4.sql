{{ dbt_utils.generate_series(upper_bound=4) }}
