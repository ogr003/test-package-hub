{{ dbt_date.get_base_dates(n_dateparts=366, datepart='day') }}
