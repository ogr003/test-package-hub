dbt snapshot
dbt run
dbt test --models fact_workitem