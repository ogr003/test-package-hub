{%- macro sql_lower(expr) -%}lower({{ expr }}){%- endmacro -%}
